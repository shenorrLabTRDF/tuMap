#' Title markersOrdering
#'
#' @param markers initial set of markers for alignment 
#' @param interScaledCancer interpolated scaled data of one cancer sample
#' @param interScaledHealthy interpolated scaled data of the averaged healthy trajectory
#' @param interScaledHPerInd interpolated scaled data of each healthy individual
#'
#' @return a dataframe with the alignment cost calculated across healthy and between the averaged healthy and AML patient 
#' @export
#' @import cellAlign
#' @import dtw

markersOrdering <- function(markers, interScaledCancer, interScaledHealthy, interScaledHPerInd){
  #calculate the mean cost per alignment step across healthy individuals using all markers:
  refCostAll = getMeanCostHealthy(markers, interScaledHPerInd, quant = 0.9)

  relMarkers = markers
  outMarkers = c() #ordered excluded markers
  refCost = refCostAll #reference cost (in healthy), initialized with reference cost of all the markers
  
  #global alignment with all the markers:
  gAlignNull = cellAlign::globalAlign(interScaledCancer$scaledData[relMarkers,], 
                                      interScaledHealthy$scaledData[relMarkers,], 
                                      step.pattern = symmetric1, normDist = F)
  itDist = gAlignNull$distance/length(gAlignNull$align[[1]]$index1) #this is the mean cost of alignment step using all markers
  
  #while we did not exclude all the markers:
  while(length(outMarkers) < (length(relMarkers) - 1)){
    #get the alignment markers - those that are not in the outMarkers list:
    alignMarkers = relMarkers[!(relMarkers %in% outMarkers)]
    
    #repeatedly exclude markers from the alignment markers list, one at a time, and recalculate the mean distance per alignment step:
    distPerMarker = do.call('rbind', lapply(alignMarkers, function(tryMarker){
      alignMarkersLOO = alignMarkers[alignMarkers != tryMarker]
      gAlign = cellAlign::globalAlign(interScaledCancer$scaledData[alignMarkersLOO,], 
                                      interScaledHealthy$scaledData[alignMarkersLOO,], 
                                      step.pattern = symmetric1, normDist = F)
      return(data.frame(LOOmarker = tryMarker, dist = gAlign$distance/length(gAlign$align[[1]]$index1)))
    }))
    
    #identify the excluded marker as thoe one whose exclusion minimized the mean cost per alignment step:
    outMarkers = c(outMarkers, as.character(distPerMarker$LOOmarker[which.min(distPerMarker$dist)]))
    #calculate the mean cost per alignment step:
    itDist = c(itDist, distPerMarker$dist[which.min(distPerMarker$dist)])
    #calculate the reference cost using this set of markers:
    refCost = c(refCost, getMeanCostHealthy(relMarkers[!(relMarkers %in% outMarkers)], interScaledHPerInd))
  }
    
  #organize the data as a dataframe:
  fetSelRes = data.frame(markers = c('all',outMarkers, relMarkers[!(relMarkers %in% outMarkers)]), 
                         dist = c(itDist,0), refCost = c(refCost,0))
  fetSelRes$markers = factor(fetSelRes$markers, levels = fetSelRes$markers)
    
  return(fetSelRes)
}