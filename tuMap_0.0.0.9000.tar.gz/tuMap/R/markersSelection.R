#' Title markersSelection
#'
#' @param orderedMarkers ordered markers along with the mean alignment cost across healthy and between cancer and averaged healthy
#'
#' @return the selected set of markers
#' @export

markersSelection <- function(orderedMarkers){
  refInd = min(which(fetSelRes$dist <= fetSelRes$refCost))
  return(as.character(fetSelRes$markers)[(refInd + 1):nrow(fetSelRes)])
}