#' Title getMeanCostHealthy
#'
#' @param markers markers used for alignment
#' @param interScaledHPerInd interpolated scaled expression of markers along the healthy trajectories
#' @param quant required quantile of the mean costs per alignment step resulting from aligning healthy individuals
#'
#' @return quantile of the mean alignment cost calculated across healthy individuals
#' @export
#' @import cellAlign

getMeanCostHealthy <- function(markers, interScaledHPerInd, quant = 0.9){
  #identify all the pairs between healthy individuals:
  combInd = t(combn(1:length(interScaledHPerInd),2))
  
  #calculate for each pair the mean cost per alignment step:
  meanStepCost = sapply(1:nrow(combInd), function(i){
    gAlignRef = cellAlign::globalAlign(interScaledHPerInd[[combInd[i,1]]]$scaledData[markers,], 
                                       interScaledHPerInd[[combInd[i,2]]]$scaledData[markers,], 
                                       step.pattern = symmetric1, normDist = F)
    return(gAlignRef$distance/length(gAlignRef$align[[1]]$index1))
  })
  return(quantile(meanStepCost, quant))
}